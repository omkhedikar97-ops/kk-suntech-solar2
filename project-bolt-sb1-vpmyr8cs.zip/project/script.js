/* ============================================================
   K K SUNTECH SOLAR — script.js
   Plain vanilla JS — no build tools, works with GitHub Pages
   ============================================================ */

(function () {
  'use strict';

  /* ── Navbar scroll ──────────────────────────────────── */
  const navbar = document.getElementById('navbar');
  function updateNavbar() {
    if (window.scrollY > 40) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }
  }
  window.addEventListener('scroll', updateNavbar, { passive: true });
  updateNavbar();

  /* ── Mobile menu ─────────────────────────────────────── */
  const hamburger = document.getElementById('hamburger');
  const navMenu = document.getElementById('navMenu');

  hamburger.addEventListener('click', function () {
    const isOpen = navMenu.classList.toggle('open');
    hamburger.classList.toggle('open');
    hamburger.setAttribute('aria-expanded', isOpen);
    document.body.style.overflow = isOpen ? 'hidden' : '';
  });

  navMenu.querySelectorAll('.nav-link').forEach(function (link) {
    link.addEventListener('click', function () {
      navMenu.classList.remove('open');
      hamburger.classList.remove('open');
      hamburger.setAttribute('aria-expanded', 'false');
      document.body.style.overflow = '';
    });
  });

  /* ── Active nav link on scroll ───────────────────────── */
  const sections = document.querySelectorAll('section[id]');
  const navLinks = document.querySelectorAll('.nav-link');

  function updateActiveNav() {
    var scrollY = window.scrollY + 120;
    sections.forEach(function (section) {
      var top = section.offsetTop;
      var height = section.offsetHeight;
      var id = section.getAttribute('id');
      if (scrollY >= top && scrollY < top + height) {
        navLinks.forEach(function (link) {
          link.classList.remove('active');
          if (link.getAttribute('href') === '#' + id) {
            link.classList.add('active');
          }
        });
      }
    });
  }
  window.addEventListener('scroll', updateActiveNav, { passive: true });
  updateActiveNav();

  /* ── Counter animation ───────────────────────────────── */
  var countersAnimated = false;
  var counterNums = document.querySelectorAll('.counter-num');

  function animateCounters() {
    if (countersAnimated) return;
    countersAnimated = true;
    counterNums.forEach(function (el) {
      var target = parseInt(el.getAttribute('data-target'), 10);
      var suffix = el.getAttribute('data-suffix') || '';
      var duration = 2000;
      var start = 0;
      var startTime = null;

      function step(timestamp) {
        if (!startTime) startTime = timestamp;
        var progress = Math.min((timestamp - startTime) / duration, 1);
        var eased = 1 - Math.pow(1 - progress, 3);
        var current = Math.floor(eased * target);
        el.textContent = current.toLocaleString('en-IN') + suffix;
        if (progress < 1) {
          requestAnimationFrame(step);
        } else {
          el.textContent = target.toLocaleString('en-IN') + suffix;
        }
      }
      requestAnimationFrame(step);
    });
  }

  /* ── Reveal on scroll ────────────────────────────────── */
  var revealEls = document.querySelectorAll('.reveal-up');

  function handleReveal() {
    revealEls.forEach(function (el) {
      var rect = el.getBoundingClientRect();
      var delay = parseInt(el.getAttribute('data-delay') || '0', 10);
      if (rect.top < window.innerHeight - 60) {
        setTimeout(function () {
          el.classList.add('revealed');
        }, delay);
      }
    });

    var counterSection = document.querySelector('.counters');
    if (counterSection) {
      var rect = counterSection.getBoundingClientRect();
      if (rect.top < window.innerHeight - 60) {
        animateCounters();
      }
    }
  }

  window.addEventListener('scroll', handleReveal, { passive: true });
  window.addEventListener('load', handleReveal);
  handleReveal();

  /* ── Testimonial slider ──────────────────────────────── */
  var testimonials = [
    {
      text: '"They handled every form, DISCOM coordination and subsidy paperwork. We didn\'t have to step out even once. True trusted local partner in Nagpur."',
      name: 'Sunita Kale',
      role: 'Resident, Mahal Nagpur',
      avatar: 'SK'
    },
    {
      text: '"Our electricity bill dropped from ₹4,500 to just ₹180 after the 3 kW installation. The PM Surya Ghar subsidy was credited within 45 days. Amazing service!"',
      name: 'Rajesh Pande',
      role: 'Homeowner, Dharampeth',
      avatar: 'RP'
    },
    {
      text: '"Professional team, clean installation in just one day. The net metering was handled completely by them. Highly recommend K K Suntech for solar in Nagpur."',
      name: 'Dr. Meena Choudhary',
      role: 'Doctor, Civil Lines Nagpur',
      avatar: 'MC'
    },
    {
      text: '"We installed a 50 kW system at our factory in Butibori. The savings are massive — over ₹80,000 per month. Their AMC plan keeps everything running smoothly."',
      name: 'Amit Bhagat',
      role: 'Industrialist, Butibori MIDC',
      avatar: 'AB'
    }
  ];

  var currentSlide = 0;
  var testimonialText = document.getElementById('testimonialText');
  var testimonialName = document.getElementById('testimonialName');
  var testimonialRole = document.getElementById('testimonialRole');
  var testimonialAvatar = document.getElementById('testimonialAvatar');
  var dots = document.querySelectorAll('#testimonialDots .dot');
  var prevBtn = document.getElementById('prevBtn');
  var nextBtn = document.getElementById('nextBtn');

  function showSlide(index) {
    currentSlide = index;
    var t = testimonials[index];
    testimonialText.textContent = t.text;
    testimonialName.textContent = t.name;
    testimonialRole.textContent = t.role;
    testimonialAvatar.textContent = t.avatar;
    dots.forEach(function (dot, i) {
      dot.classList.toggle('active', i === index);
      dot.setAttribute('aria-selected', i === index ? 'true' : 'false');
    });
  }

  prevBtn.addEventListener('click', function () {
    showSlide((currentSlide - 1 + testimonials.length) % testimonials.length);
  });
  nextBtn.addEventListener('click', function () {
    showSlide((currentSlide + 1) % testimonials.length);
  });
  dots.forEach(function (dot) {
    dot.addEventListener('click', function () {
      showSlide(parseInt(dot.getAttribute('data-index'), 10));
    });
  });

  var autoSlide = setInterval(function () {
    showSlide((currentSlide + 1) % testimonials.length);
  }, 6000);

  document.querySelector('.testimonial-wrapper').addEventListener('mouseenter', function () {
    clearInterval(autoSlide);
  });
  document.querySelector('.testimonial-wrapper').addEventListener('mouseleave', function () {
    autoSlide = setInterval(function () {
      showSlide((currentSlide + 1) % testimonials.length);
    }, 6000);
  });

  /* ── FAQ accordion ───────────────────────────────────── */
  document.querySelectorAll('.faq-question').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var item = btn.closest('.faq-item');
      var isOpen = item.classList.contains('open');

      document.querySelectorAll('.faq-item.open').forEach(function (openItem) {
        openItem.classList.remove('open');
        openItem.querySelector('.faq-question').setAttribute('aria-expanded', 'false');
      });

      if (!isOpen) {
        item.classList.add('open');
        btn.setAttribute('aria-expanded', 'true');
      }
    });
  });

  /* ── Contact form ────────────────────────────────────── */
  var contactForm = document.getElementById('contactForm');
  var formSuccess = document.getElementById('formSuccess');
  var submitBtn = document.getElementById('submitBtn');

  contactForm.addEventListener('submit', function (e) {
    e.preventDefault();

    var name = document.getElementById('name');
    var phone = document.getElementById('phone');
    var valid = true;

    [name, phone].forEach(function (field) {
      field.classList.remove('error');
      if (!field.value.trim()) {
        field.classList.add('error');
        valid = false;
      }
    });

    if (phone.value.trim() && !/^[0-9+\-\s]{7,15}$/.test(phone.value.trim())) {
      phone.classList.add('error');
      valid = false;
    }

    if (!valid) return;

    submitBtn.disabled = true;
    submitBtn.textContent = 'Sending...';

    setTimeout(function () {
      contactForm.hidden = true;
      formSuccess.hidden = false;
    }, 800);
  });

  [document.getElementById('name'), document.getElementById('phone')].forEach(function (field) {
    field.addEventListener('input', function () {
      field.classList.remove('error');
    });
  });

  /* ── Smooth scroll for anchor links ──────────────────── */
  document.querySelectorAll('a[href^="#"]').forEach(function (anchor) {
    anchor.addEventListener('click', function (e) {
      var target = document.querySelector(this.getAttribute('href'));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

})();
